#!/bin/bash
# ============================================================
#   INSTALL SCRIPT — Bot WhatsApp OGH-ZIV UDP ZiVPN
#   Jalankan sebagai root di VPS yang sudah ada OGH-ZIV
# ============================================================

RED='\033[1;31m'; GREEN='\033[1;32m'; YELLOW='\033[1;33m'
CYAN='\033[1;36m'; WHITE='\033[1;37m'; NC='\033[0m'

ok()   { echo -e "  ${GREEN}✔${NC}  $*"; }
inf()  { echo -e "  ${CYAN}➜${NC}  $*"; }
warn() { echo -e "  ${YELLOW}⚠${NC}  $*"; }
err()  { echo -e "  ${RED}✘${NC}  $*"; }

clear
echo ""
echo -e "${CYAN}  ╔══════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}  ║   🤖  INSTALL BOT WHATSAPP — OGH-ZIV ZIVPN     ║${NC}"
echo -e "${CYAN}  ╚══════════════════════════════════════════════════╝${NC}"
echo ""

# Cek root
[[ $EUID -ne 0 ]] && { err "Jalankan sebagai root!"; exit 1; }

# Cek OS
source /etc/os-release 2>/dev/null
OS_ID=$(echo "${ID}" | tr '[:upper:]' '[:lower:]')
inf "OS: ${PRETTY_NAME}"

# ── Install Node.js 20 ─────────────────────────────────────
if ! command -v node &>/dev/null || [[ $(node -v | tr -d 'v' | cut -d. -f1) -lt 18 ]]; then
    inf "Menginstall Node.js 20..."
    apt-get update -qq &>/dev/null
    apt-get install -y -qq curl &>/dev/null
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash - &>/dev/null
    apt-get install -y -qq nodejs &>/dev/null
    ok "Node.js $(node -v) terinstall"
else
    ok "Node.js $(node -v) sudah ada"
fi

# ── Install Chromium & deps ─────────────────────────────────
inf "Menginstall Chromium & dependensi..."
apt-get install -y -qq \
    chromium-browser \
    libnss3 libatk1.0-0 libatk-bridge2.0-0 \
    libcups2 libdrm2 libxkbcommon0 libxcomposite1 \
    libxdamage1 libxfixes3 libxrandr2 libgbm1 \
    libasound2 libpango-1.0-0 libpangocairo-1.0-0 \
    fonts-liberation &>/dev/null
ok "Chromium & deps terinstall"

# ── Tentukan folder bot ─────────────────────────────────────
BOT_DIR="/opt/wa-bot-zivpn"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ "$SCRIPT_DIR" != "$BOT_DIR" ]]; then
    inf "Menyalin file bot ke $BOT_DIR..."
    mkdir -p "$BOT_DIR"
    cp -r "$SCRIPT_DIR"/* "$BOT_DIR/" 2>/dev/null
    ok "File disalin ke $BOT_DIR"
fi

cd "$BOT_DIR" || exit 1

# ── Install npm dependencies ────────────────────────────────
inf "Menginstall npm packages..."
npm install --silent 2>/dev/null
ok "npm packages terinstall"

# ── Setup config jika belum ─────────────────────────────────
if grep -q '6281234567890' "$BOT_DIR/config.js" 2>/dev/null; then
    echo ""
    echo -e "${YELLOW}  ╔══════════════════════════════════════════════════╗${NC}"
    echo -e "${YELLOW}  ║   ⚙️   KONFIGURASI BOT                           ║${NC}"
    echo -e "${YELLOW}  ╚══════════════════════════════════════════════════╝${NC}"
    echo ""

    read -p "  Nomor WA Admin (format: 628xxx tanpa +): " ADMIN_NUM
    read -p "  Nomor DANA: " DANA_NUM
    read -p "  Nama pemilik DANA: " DANA_NAME
    read -p "  Nama Brand/Toko: " BRAND_NAME

    [[ -n "$ADMIN_NUM" ]] && sed -i "s/6281234567890/$ADMIN_NUM/g" "$BOT_DIR/config.js"
    [[ -n "$DANA_NUM" ]]  && sed -i "s/081234567890/$DANA_NUM/g" "$BOT_DIR/config.js"
    [[ -n "$DANA_NAME" ]] && sed -i "s/Nama Pemilik DANA/$DANA_NAME/g" "$BOT_DIR/config.js"
    [[ -n "$BRAND_NAME" ]] && sed -i "s/OGH-ZIV VPN/$BRAND_NAME/g" "$BOT_DIR/config.js"

    ok "Config berhasil diupdate"
fi

# ── Buat systemd service ────────────────────────────────────
inf "Membuat systemd service..."
cat > /etc/systemd/system/wa-bot-zivpn.service <<SVCEOF
[Unit]
Description=WhatsApp Bot OGH-ZIV ZiVPN
After=network.target
Wants=network-online.target

[Service]
Type=simple
User=root
WorkingDirectory=${BOT_DIR}
ExecStart=/usr/bin/node ${BOT_DIR}/bot.js
Restart=always
RestartSec=10
StandardOutput=append:/var/log/wa-bot-zivpn.log
StandardError=append:/var/log/wa-bot-zivpn.log
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
SVCEOF

systemctl daemon-reload
systemctl enable wa-bot-zivpn &>/dev/null
ok "Systemd service dibuat"

# ── Buat command shortcut ───────────────────────────────────
cat > /usr/local/bin/bot-wa <<'CMDEOF'
#!/bin/bash
case "${1:-}" in
    start)   systemctl start wa-bot-zivpn && echo "✅ Bot started" ;;
    stop)    systemctl stop wa-bot-zivpn && echo "⛔ Bot stopped" ;;
    restart) systemctl restart wa-bot-zivpn && echo "🔄 Bot restarted" ;;
    status)  systemctl status wa-bot-zivpn --no-pager ;;
    log)     tail -50 /var/log/wa-bot-zivpn.log ;;
    qr)      cd /opt/wa-bot-zivpn && node bot.js ;;
    *)
        echo ""
        echo "  🤖 Bot WhatsApp ZiVPN"
        echo "  ─────────────────────────────"
        echo "  bot-wa start    — Mulai bot"
        echo "  bot-wa stop     — Stop bot"
        echo "  bot-wa restart  — Restart bot"
        echo "  bot-wa status   — Status bot"
        echo "  bot-wa log      — Lihat log"
        echo "  bot-wa qr       — Scan ulang QR"
        echo ""
        ;;
esac
CMDEOF
chmod +x /usr/local/bin/bot-wa
ok "Command 'bot-wa' tersedia"

# ── Done ────────────────────────────────────────────────────
echo ""
echo -e "${GREEN}  ╔══════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}  ║   ✅  INSTALASI SELESAI!                         ║${NC}"
echo -e "${GREEN}  ╠══════════════════════════════════════════════════╣${NC}"
echo -e "${GREEN}  ║${NC}  Langkah selanjutnya:                              ${GREEN}║${NC}"
echo -e "${GREEN}  ║${NC}                                                    ${GREEN}║${NC}"
echo -e "${GREEN}  ║${NC}  1. Edit config jika perlu:                        ${GREEN}║${NC}"
echo -e "${GREEN}  ║${NC}     nano ${BOT_DIR}/config.js                   ${GREEN}║${NC}"
echo -e "${GREEN}  ║${NC}                                                    ${GREEN}║${NC}"
echo -e "${GREEN}  ║${NC}  2. Jalankan bot & scan QR:                        ${GREEN}║${NC}"
echo -e "${GREEN}  ║${NC}     ${WHITE}bot-wa qr${GREEN}                                    ║${NC}"
echo -e "${GREEN}  ║${NC}                                                    ${GREEN}║${NC}"
echo -e "${GREEN}  ║${NC}  3. Setelah scan, jalankan sebagai service:        ${GREEN}║${NC}"
echo -e "${GREEN}  ║${NC}     ${WHITE}bot-wa start${GREEN}                                 ║${NC}"
echo -e "${GREEN}  ║${NC}                                                    ${GREEN}║${NC}"
echo -e "${GREEN}  ║${NC}  4. Cek status:                                    ${GREEN}║${NC}"
echo -e "${GREEN}  ║${NC}     ${WHITE}bot-wa status${GREEN}                                ║${NC}"
echo -e "${GREEN}  ╚══════════════════════════════════════════════════╝${NC}"
echo ""
