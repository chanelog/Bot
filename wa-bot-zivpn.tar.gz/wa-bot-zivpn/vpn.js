'use strict';

// ============================================================
//   VPN HELPER — Integrasi langsung dengan OGH-ZIV ZiVPN
//   Baca/tulis /etc/zivpn/users.db dan reload config
// ============================================================

const fs   = require('fs');
const path = require('path');
const { execSync } = require('child_process');
const config = require('./config');

// ── Utils ─────────────────────────────────────────────────────
function randPass(len = 12) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let out = '';
    for (let i = 0; i < len; i++) out += chars[Math.floor(Math.random() * chars.length)];
    return out;
}

function randUsername(prefix = 'trial') {
    const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
    let suf = '';
    for (let i = 0; i < 6; i++) suf += chars[Math.floor(Math.random() * chars.length)];
    return prefix + suf;
}

function addDays(days) {
    const d = new Date();
    d.setDate(d.getDate() + days);
    return d.toISOString().split('T')[0]; // YYYY-MM-DD
}

// ── Baca semua user dari UDB ──────────────────────────────────
function listUsers() {
    if (!fs.existsSync(config.UDB_PATH)) return [];
    const raw = fs.readFileSync(config.UDB_PATH, 'utf8').trim();
    if (!raw) return [];
    return raw.split('\n').filter(Boolean).map(line => {
        const [username, password, exp, quota, note] = line.split('|');
        return { username, password, exp, quota: quota || '0', note: note || '' };
    });
}

// ── Cek apakah username sudah ada ─────────────────────────────
function userExists(username) {
    const users = listUsers();
    return users.some(u => u.username.toLowerCase() === username.toLowerCase());
}

// ── Ambil info 1 user ──────────────────────────────────────────
function getAccountInfo(username) {
    const users = listUsers();
    const u = users.find(x => x.username.toLowerCase() === username.toLowerCase());
    if (!u) return null;
    return {
        username: u.username,
        password: u.password,
        exp: u.exp,
        quota: u.quota === '0' ? 'Unlimited' : `${u.quota} GB`,
        note: u.note,
        domain: getDomain(),
        port: getPort(),
    };
}

// ── Buat akun baru ─────────────────────────────────────────────
function createUser(username, password, days, quota = 'Unlimited', note = '-') {
    try {
        if (userExists(username)) {
            return { success: false, error: `Username "${username}" sudah dipakai.` };
        }

        const exp     = addDays(days);
        const quotaDB = (quota === 'Unlimited' || quota === '0') ? '0' : String(parseInt(quota));
        const line    = `${username}|${password}|${exp}|${quotaDB}|${note}\n`;

        fs.appendFileSync(config.UDB_PATH, line, 'utf8');
        reloadVPN();

        return { success: true, username, password, exp };
    } catch (e) {
        return { success: false, error: e.message };
    }
}

// ── Buat akun trial ───────────────────────────────────────────
function createTrialUser(phone = '') {
    const username = randUsername('trial');
    const password = randPass(10);
    const days     = config.TRIAL_HARI || 1;
    const kuotaGB  = config.TRIAL_KUOTA_GB || 1;

    return createUser(username, password, days, String(kuotaGB), `TRIAL-${phone}`);
}

// ── Hapus akun ────────────────────────────────────────────────
function deleteUser(username) {
    try {
        if (!fs.existsSync(config.UDB_PATH)) {
            return { success: false, error: 'File users.db tidak ditemukan.' };
        }
        const raw  = fs.readFileSync(config.UDB_PATH, 'utf8');
        const lines = raw.split('\n').filter(Boolean);
        const before = lines.length;
        const after  = lines.filter(l => {
            const u = l.split('|')[0];
            return u.toLowerCase() !== username.toLowerCase();
        });
        if (after.length === before) {
            return { success: false, error: `Username "${username}" tidak ditemukan.` };
        }
        fs.writeFileSync(config.UDB_PATH, after.join('\n') + (after.length ? '\n' : ''), 'utf8');
        reloadVPN();
        return { success: true };
    } catch (e) {
        return { success: false, error: e.message };
    }
}

// ── Perpanjang akun ───────────────────────────────────────────
function renewUser(username, days) {
    try {
        if (!fs.existsSync(config.UDB_PATH)) {
            return { success: false, error: 'File users.db tidak ditemukan.' };
        }
        const raw   = fs.readFileSync(config.UDB_PATH, 'utf8');
        const lines = raw.split('\n').filter(Boolean);
        let found = false;
        const updated = lines.map(line => {
            const parts = line.split('|');
            if (parts[0].toLowerCase() === username.toLowerCase()) {
                found = true;
                const today   = new Date().toISOString().split('T')[0];
                const baseExp = parts[2] < today ? today : parts[2];
                const newExp  = addDaysFrom(baseExp, days);
                parts[2] = newExp;
                return parts.join('|');
            }
            return line;
        });
        if (!found) return { success: false, error: `Username "${username}" tidak ditemukan.` };
        fs.writeFileSync(config.UDB_PATH, updated.join('\n') + '\n', 'utf8');
        reloadVPN();
        const newExpDate = updated.find(l => l.startsWith(username + '|'))?.split('|')[2];
        return { success: true, newExp: newExpDate };
    } catch (e) {
        return { success: false, error: e.message };
    }
}

// ── Hapus akun expired ────────────────────────────────────────
function cleanExpired() {
    try {
        const today = new Date().toISOString().split('T')[0];
        const raw   = fs.readFileSync(config.UDB_PATH, 'utf8');
        const lines = raw.split('\n').filter(Boolean);
        const active = lines.filter(l => {
            const exp = l.split('|')[2];
            return exp && exp >= today;
        });
        if (active.length !== lines.length) {
            fs.writeFileSync(config.UDB_PATH, active.join('\n') + (active.length ? '\n' : ''), 'utf8');
            reloadVPN();
        }
        return { removed: lines.length - active.length };
    } catch (e) {
        return { removed: 0, error: e.message };
    }
}

// ── Statistik akun ─────────────────────────────────────────────
function getVpnStats() {
    const users = listUsers();
    const today = new Date().toISOString().split('T')[0];
    const active  = users.filter(u => u.exp >= today).length;
    const expired = users.filter(u => u.exp < today).length;
    return { total: users.length, active, expired };
}

// ── Baca domain dari domain.conf ──────────────────────────────
function getDomain() {
    try {
        if (fs.existsSync(config.DOMAIN_PATH)) {
            return fs.readFileSync(config.DOMAIN_PATH, 'utf8').trim();
        }
    } catch {}
    return getPublicIP();
}

// ── Baca port dari config.json ────────────────────────────────
function getPort() {
    try {
        if (fs.existsSync(config.CFG_PATH)) {
            const c = JSON.parse(fs.readFileSync(config.CFG_PATH, 'utf8'));
            const listen = c.listen || ':5667';
            return listen.replace(':', '');
        }
    } catch {}
    return '5667';
}

// ── Ambil IP publik ───────────────────────────────────────────
function getPublicIP() {
    try {
        return execSync(
            'curl -s4 --max-time 5 https://ifconfig.me 2>/dev/null || hostname -I | awk \'{print $1}\'',
            { timeout: 8000 }
        ).toString().trim();
    } catch {
        return 'IP-VPS';
    }
}

// ── Reload password ke config.json & restart service ──────────
function reloadVPN() {
    try {
        // 1. Baca semua password dari UDB
        if (!fs.existsSync(config.UDB_PATH) || !fs.existsSync(config.CFG_PATH)) return;

        const raw  = fs.readFileSync(config.UDB_PATH, 'utf8').trim();
        const pwds = raw.split('\n').filter(Boolean).map(l => l.split('|')[1]).filter(Boolean);

        // 2. Update auth.config di config.json
        const cfg = JSON.parse(fs.readFileSync(config.CFG_PATH, 'utf8'));
        if (!cfg.auth) cfg.auth = {};
        cfg.auth.mode   = 'passwords';
        cfg.auth.config = pwds;
        fs.writeFileSync(config.CFG_PATH, JSON.stringify(cfg, null, 2), 'utf8');

        // 3. Restart zivpn service
        execSync('systemctl restart zivpn 2>/dev/null || true', { timeout: 10000 });
    } catch (e) {
        console.error('❌ Gagal reload VPN:', e.message);
    }
}

// ── Helper: addDays dari tanggal tertentu ─────────────────────
function addDaysFrom(dateStr, days) {
    const d = new Date(dateStr);
    d.setDate(d.getDate() + parseInt(days));
    return d.toISOString().split('T')[0];
}

module.exports = {
    listUsers, userExists, getAccountInfo,
    createUser, createTrialUser, deleteUser, renewUser,
    cleanExpired, getVpnStats,
    getDomain, getPort, getPublicIP, reloadVPN,
    randPass, randUsername,
};
