'use strict';

// ============================================================
//   DATABASE HELPER — SQLite via better-sqlite3
//   Tabel: orders, trials, buyers
// ============================================================

const Database = require('better-sqlite3');
const path = require('path');

let db;

function init() {
    db = new Database(path.join(__dirname, 'bot.db'));
    db.pragma('journal_mode = WAL');

    db.exec(`
        CREATE TABLE IF NOT EXISTS orders (
            id              TEXT PRIMARY KEY,
            phone           TEXT NOT NULL,
            package_id      TEXT,
            package_name    TEXT,
            days            INTEGER,
            amount          INTEGER,
            payment_method  TEXT,
            vpn_username    TEXT,
            vpn_password    TEXT,
            screenshot_path TEXT,
            status          TEXT DEFAULT 'pending',
            created_at      INTEGER DEFAULT (strftime('%s','now')),
            updated_at      INTEGER
        );

        CREATE TABLE IF NOT EXISTS trials (
            phone   TEXT NOT NULL,
            date    TEXT NOT NULL,
            PRIMARY KEY (phone, date)
        );

        CREATE TABLE IF NOT EXISTS buyers (
            phone           TEXT PRIMARY KEY,
            registered_at   INTEGER DEFAULT (strftime('%s','now')),
            last_seen       INTEGER DEFAULT (strftime('%s','now'))
        );

        CREATE INDEX IF NOT EXISTS idx_orders_phone  ON orders(phone);
        CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
    `);

    console.log('✅ Database siap.');
}

// ── Orders ────────────────────────────────────────────────────
function createOrder(data) {
    const stmt = db.prepare(`
        INSERT INTO orders
            (id, phone, package_id, package_name, days, amount,
             payment_method, vpn_username, vpn_password, screenshot_path, status)
        VALUES
            (@id, @phone, @package_id, @package_name, @days, @amount,
             @payment_method, @vpn_username, @vpn_password, @screenshot_path, @status)
    `);
    stmt.run(data);
}

function getOrder(id) {
    return db.prepare('SELECT * FROM orders WHERE id = ?').get(id);
}

function getPendingOrders() {
    return db.prepare(
        "SELECT * FROM orders WHERE status = 'pending' ORDER BY created_at DESC"
    ).all();
}

function updateOrderStatus(id, status) {
    db.prepare(`
        UPDATE orders
        SET status = ?, updated_at = strftime('%s','now')
        WHERE id = ?
    `).run(status, id);
}

function getOrdersByPhone(phone) {
    return db.prepare(
        'SELECT * FROM orders WHERE phone = ? ORDER BY created_at DESC'
    ).all(phone);
}

function getApprovedOrdersByPhone(phone) {
    return db.prepare(
        "SELECT * FROM orders WHERE phone = ? AND status = 'approved' ORDER BY created_at DESC"
    ).all(phone);
}

function getAllOrders() {
    return db.prepare('SELECT * FROM orders ORDER BY created_at DESC').all();
}

function expireOldOrders(timeoutJam) {
    const cutoff = Math.floor(Date.now() / 1000) - timeoutJam * 3600;
    db.prepare(`
        UPDATE orders
        SET status = 'expired', updated_at = strftime('%s','now')
        WHERE status = 'pending' AND created_at < ?
    `).run(cutoff);
}

// ── Trials ────────────────────────────────────────────────────
function hasTrialToday(phone) {
    const today = new Date().toISOString().split('T')[0];
    const row = db.prepare(
        'SELECT 1 FROM trials WHERE phone = ? AND date = ?'
    ).get(phone, today);
    return !!row;
}

function recordTrial(phone) {
    const today = new Date().toISOString().split('T')[0];
    db.prepare(
        'INSERT OR IGNORE INTO trials (phone, date) VALUES (?, ?)'
    ).run(phone, today);
}

function getTrialCount(phone) {
    const row = db.prepare(
        'SELECT COUNT(*) AS cnt FROM trials WHERE phone = ?'
    ).get(phone);
    return row ? row.cnt : 0;
}

// ── Buyers ────────────────────────────────────────────────────
function registerBuyer(phone) {
    db.prepare(`
        INSERT INTO buyers (phone) VALUES (?)
        ON CONFLICT(phone) DO UPDATE SET last_seen = strftime('%s','now')
    `).run(phone);
}

function getAllBuyers() {
    return db.prepare('SELECT * FROM buyers ORDER BY registered_at DESC').all();
}

function getBuyerCount() {
    const row = db.prepare('SELECT COUNT(*) AS cnt FROM buyers').get();
    return row ? row.cnt : 0;
}

// ── Stats ─────────────────────────────────────────────────────
function getStats() {
    const total_orders    = db.prepare("SELECT COUNT(*) AS cnt FROM orders").get().cnt;
    const pending_orders  = db.prepare("SELECT COUNT(*) AS cnt FROM orders WHERE status='pending'").get().cnt;
    const approved_orders = db.prepare("SELECT COUNT(*) AS cnt FROM orders WHERE status='approved'").get().cnt;
    const rejected_orders = db.prepare("SELECT COUNT(*) AS cnt FROM orders WHERE status='rejected'").get().cnt;
    const total_buyers    = db.prepare("SELECT COUNT(*) AS cnt FROM buyers").get().cnt;
    const today           = new Date().toISOString().split('T')[0];
    const today_trials    = db.prepare("SELECT COUNT(*) AS cnt FROM trials WHERE date=?").get(today).cnt;
    const today_income    = db.prepare(
        "SELECT COALESCE(SUM(amount),0) AS total FROM orders WHERE status='approved' AND date(created_at,'unixepoch')=?"
    ).get(today).total;
    const total_income    = db.prepare(
        "SELECT COALESCE(SUM(amount),0) AS total FROM orders WHERE status='approved'"
    ).get().total;

    return {
        total_orders, pending_orders, approved_orders, rejected_orders,
        total_buyers, today_trials, today_income, total_income
    };
}

module.exports = {
    init,
    createOrder, getOrder, getPendingOrders, updateOrderStatus,
    getOrdersByPhone, getApprovedOrdersByPhone, getAllOrders, expireOldOrders,
    hasTrialToday, recordTrial, getTrialCount,
    registerBuyer, getAllBuyers, getBuyerCount,
    getStats,
};
